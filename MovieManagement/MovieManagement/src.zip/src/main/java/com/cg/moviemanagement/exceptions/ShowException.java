package com.cg.moviemanagement.exceptions;

public class ShowException extends Exception {
	public ShowException(String s)
	{
		super(s);
	}

	public ShowException() {
		super();
		
	}

	
}