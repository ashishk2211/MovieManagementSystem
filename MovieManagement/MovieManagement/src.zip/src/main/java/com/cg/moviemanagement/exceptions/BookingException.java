package com.cg.moviemanagement.exceptions;

public class BookingException extends Exception{

	public BookingException() {
		super();
		
	}

	public BookingException(String arg0) {
		super(arg0);
		
	}

	
}
